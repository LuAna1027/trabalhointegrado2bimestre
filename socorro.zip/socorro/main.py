from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///socorro.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)


app.app_context().push()
db.create_all()
# Modelos
class Admin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)

class Team(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    city = db.Column(db.String(150), nullable=False)

# Rotas
@app.route('/')
def index():
    return render_template('vamo.html', page='index')

@app.route('/register_team', methods=['GET', 'POST'])
def register_team():
    if request.method == 'POST':
        name = request.form['name']
        city = request.form['city']
        new_team = Team(name=name, city=city)
        db.session.add(new_team)
        db.session.commit()
        flash('Equipe cadastrada com sucesso!')
        return redirect(url_for('index'))
    return render_template('vamo.html', page='register_team')

@app.route('/register_admin', methods=['GET', 'POST'])
def register_admin():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_admin = Admin(username=username, password=hashed_password)
        db.session.add(new_admin)
        db.session.commit()
        flash('Administrador cadastrado com sucesso!')
        return redirect(url_for('index'))
    return render_template('vamo.html', page='register_admin')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        admin = Admin.query.filter_by(username=username).first()
        if admin and check_password_hash(admin.password, password):
            return redirect(url_for('dashboard'))
        flash('Nome de usuário ou senha incorretos.')
    return render_template('vamo.html', page='login')

@app.route('/dashboard')
def dashboard():
    teams = Team.query.all()
    return render_template('vamo.html', page='dashboard', teams=teams)

if __name__ == '__main__':
    app.run(debug=True)

